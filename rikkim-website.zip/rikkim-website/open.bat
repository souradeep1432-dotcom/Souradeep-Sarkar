@echo off
cd /d "%~dp0"
rem Fix double extensions like logo-light.jpeg.jpeg
if exist "logo-light.jpeg.jpeg" ren "logo-light.jpeg.jpeg" "logo-light.jpeg"
if exist "logo-dark.jpeg.jpeg" ren "logo-dark.jpeg.jpeg" "logo-dark.jpeg"
if not exist "logo-light.jpeg" echo WARNING: logo-light.jpeg not found in this folder.
start "" "rikkim.html"
